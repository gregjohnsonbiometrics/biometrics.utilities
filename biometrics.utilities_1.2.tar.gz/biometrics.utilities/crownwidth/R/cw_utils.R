## ---------------------------------------------------------------------------
## cw_utils.R -- shared machinery for mcw() and lcw().
##
## Base R and data.table only. No tidyverse, no brms, no fit object: every
## number these functions return comes from the coefficient library staged in
## inst/extdata/cw_parameters.csv (or, once data-raw/build_sysdata.R has been
## run, from the internal object .cw_parameters_internal).
##
## THE SHIPPED RECIPE, IN ORDER. The order is load bearing and reversing the
## last two steps changes the answer for 13 species.
##   1. Evaluate cw = a1 * dbh^a2 with a1 the TRAIT CORRECTED level, which is
##      what the a1 column of the library of record carries.
##   2. Hold dbh at dbh_max_fit for any larger diameter, so the curve is never
##      evaluated above the range it was fit over. Below dbh_min_fit nothing is
##      held; the provenance column below_fit_domain flags those elements.
##   3. Cap the result at cw_ceiling, the widest crown observed in that clade.
## Step 3 is not implied by step 2. For the 13 species with
## ceiling_binds_in_fit set, a1 * dbh_max_fit^a2 is itself above the ceiling,
## eastern cottonwood most visibly at 101.13 ft against a 75.0 ft hardwood
## ceiling, and only step 3 brings it down. The library column cw_shipped_max
## is min(cw_at_dbh_max, cw_ceiling) and is what this recipe returns at and
## above dbh_max_fit; cw_at_dbh_max alone is not.
## ---------------------------------------------------------------------------

.cw_env <- new.env(parent = emptyenv())

## data.table's `[` only uses its own non standard evaluation when the calling
## package is declared data.table aware. Without this flag the package's own
## test code, which testthat evaluates inside this namespace, silently falls
## back to `[.data.frame` and every P[spcd == 202L] in the suite errors. The
## package Imports data.table but imports no symbol from it by name, so the
## flag is the documented way to make cedta() see it.
.datatable.aware <- TRUE

#' Crown width parameter table
#'
#' The staged coefficient table behind \code{\link{mcw}} and \code{\link{lcw}},
#' one row per FIA species code, 523 codes. Returned as a copy, so modifying it
#' does not disturb the package state.
#'
#' Coefficients: \code{a1} and \code{a2} (the trait corrected power
#' coefficients, DBH inches and crown width feet) and the four LCW ratio
#' parameters, each with its 95 percent interval in \code{<coef>_ci95_lo} and
#' \code{<coef>_ci95_hi}. For a borrowed code the point estimate is the
#' donor's and the interval is the donor's widened for the between species
#' spread and scaled by \code{c_cal}. Domain: \code{dbh_min_fit},
#' \code{dbh_max_fit}, \code{cw_ceiling}, \code{cw_shipped_max} and the
#' related columns, taken from \code{env_source_spcd}.
#'
#' Provenance, three disjoint vocabularies: \code{extension_route} (direct,
#' genus, hand, spgrp, clade_population, no_donor), \code{fit_evidence}
#' (self_informed, partially_pooled, prior_dominated, population_mean; for a
#' borrowed code it describes the donor's fit) and \code{confidence}
#' (direct_strong, direct_shrunk, direct_prior_dominated, genus_proxy,
#' spgrp_proxy, clade_mean, none). Also \code{source_spcd},
#' \code{donor_is_prior_dominated}, \code{c_cal}, \code{env_source},
#' \code{env_source_spcd}, \code{n_obs} (the code's own trees, zero when
#' borrowed), \code{donor_n_obs}, \code{note} and \code{param_source_md5}.
#'
#' @return A \code{data.table} with one row per species code.
#' @examples
#' p <- cw_parameters()
#' nrow(p)
#' table(p$extension_route)
#' table(p$confidence)
#' @export
cw_parameters <- function() {
  data.table::copy(.cw_load())
}

#' Version string of the coefficient library in use
#'
#' @return A length one character vector naming the library export the staged
#'   parameters were read from.
#' @examples
#' cw_library_version()
#' @export
cw_library_version <- function() {
  p <- .cw_load()
  as.character(p[["library_version"]][1L])
}

## Load once, cache in .cw_env. Prefers the internal object written by
## data-raw/build_sysdata.R; falls back to the staged CSV so that a fresh
## checkout works before sysdata.rda has been rebuilt.
.cw_load <- function() {
  if (!is.null(.cw_env$par)) return(.cw_env$par)
  p <- tryCatch({
    ns <- asNamespace(.cw_pkgname())
    if (exists(".cw_parameters_internal", envir = ns, inherits = FALSE))
      data.table::as.data.table(get(".cw_parameters_internal", envir = ns))
    else NULL
  }, error = function(e) NULL)
  if (is.null(p)) {
    f <- tryCatch(system.file("extdata", "cw_parameters.csv",
                              package = .cw_pkgname()),
                  error = function(e) "")
    for (alt in c(file.path("inst", "extdata", "cw_parameters.csv"),
                  file.path("..", "inst", "extdata", "cw_parameters.csv"),
                  file.path("..", "..", "inst", "extdata", "cw_parameters.csv")))
      if (!nzchar(f) || !file.exists(f)) if (file.exists(alt)) f <- alt
    if (!nzchar(f) || !file.exists(f))
      stop("crown width parameters not found. Run data-raw/build_sysdata.R, ",
           "or place cw_parameters.csv in inst/extdata/.", call. = FALSE)
    p <- data.table::fread(f, na.strings = c("", "NA"))
  }
  p <- data.table::copy(p)
  cf  <- c("a1", "a2", "ratio_intercept", "ratio_cr", "ratio_dbh", "ratio_phi")
  num <- c(cf, paste0(cf, "_ci95_lo"), paste0(cf, "_ci95_hi"), "c_cal",
           "dbh_min_fit", "dbh_max_fit", "cw_at_dbh_max", "cw_ceiling",
           "dbh_at_ceiling", "cw_shipped_max", "n_obs", "donor_n_obs")
  for (j in num) data.table::set(p, j = j, value = as.numeric(p[[j]]))
  data.table::set(p, j = "spcd", value = as.integer(p[["spcd"]]))
  for (j in c("source_spcd", "env_source_spcd"))
    data.table::set(p, j = j, value = suppressWarnings(as.integer(p[[j]])))
  for (j in c("ceiling_binds_in_fit", "donor_is_prior_dominated"))
    data.table::set(p, j = j, value = as.logical(p[[j]]))
  data.table::setkeyv(p, "spcd")
  .cw_env$par <- p
  p
}

## The package name is read from the environment this file is installed into so
## that renaming the package (see README) needs no edit here.
.cw_pkgname <- function() {
  e <- environment(.cw_load)
  n <- environmentName(topenv(e))
  if (identical(n, "R_GlobalEnv") || !nzchar(n)) "crownwidth" else n
}

## ---- argument validation --------------------------------------------------

## Recycle spcd and dbh_in to a common length, or stop. n_extra is the length
## of a third argument that also participates in the recycling: lcw() passes
## length(cr), so that lcw(202, 30, cr = c(0.2, 0.6, 1.0)) returns three values
## rather than rejecting cr. mcw() has no such argument and passes nothing.
.cw_recycle <- function(spcd, dbh_in, n_extra = 0L) {
  ls <- length(spcd); ld <- length(dbh_in)
  if (ls == 0L || ld == 0L) {
    ## empty input is allowed only when every argument is empty or length 1,
    ## so mcw(integer(0), 1:3) is a length error rather than a silent empty
    if (max(ls, ld, n_extra) > 1L)
      stop("spcd has length ", ls, " and dbh_in has length ", ld,
           "; an empty argument cannot recycle against a longer one.",
           call. = FALSE)
    return(list(spcd = spcd[0L], dbh = dbh_in[0L], n = 0L))
  }
  n <- max(ls, ld, n_extra)
  if (!ls %in% c(1L, n))
    stop("spcd must be length 1 or the recycled length ", n, "; got ",
         ls, ".", call. = FALSE)
  if (!ld %in% c(1L, n))
    stop("dbh_in must be length 1 or the recycled length ", n, "; got ",
         ld, ".", call. = FALSE)
  list(spcd = rep(spcd, length.out = n), dbh = rep(dbh_in, length.out = n), n = n)
}

## A factor is converted through its labels, never its level numbers: a
## factor built from c(202, 12) has levels "12" and "202", and as.numeric on
## it would return 2 and 1.
.cw_num <- function(x) {
  if (is.factor(x)) x <- as.character(x)
  suppressWarnings(as.numeric(x))
}

## The recipe switches must be a single TRUE or FALSE; NA or "yes" is an error
## rather than a silent FALSE.
.cw_flag <- function(x, name) {
  if (!(isTRUE(x) || isFALSE(x)))
    stop(name, " must be TRUE or FALSE.", call. = FALSE)
  isTRUE(x)
}

.cw_check_dbh <- function(dbh_in) {
  d <- .cw_num(dbh_in)
  if (any(is.na(d)))
    stop("dbh_in carries ", sum(is.na(d)), " missing or non numeric value(s); ",
         "crown width is undefined there. Drop or impute those rows before ",
         "calling.", call. = FALSE)
  if (any(!is.finite(d)))
    stop("dbh_in carries ", sum(!is.finite(d)), " infinite value(s).",
         call. = FALSE)
  if (any(d < 0))
    stop("dbh_in carries ", sum(d < 0), " negative value(s), the smallest ",
         signif(min(d), 6), ". DBH must be non negative.", call. = FALSE)
  d
}

.cw_check_cr <- function(cr, n) {
  if (!length(cr) %in% c(1L, n))
    stop("cr must be length 1 or ", n, "; got ", length(cr), ".", call. = FALSE)
  x <- .cw_num(cr)
  if (any(is.na(x)))
    stop("cr carries ", sum(is.na(x)), " missing or non numeric value(s).",
         call. = FALSE)
  if (any(x <= 0 | x > 1))
    stop("cr must lie in (0, 1]; it is a proportion, not a percentage. ",
         "Offending range ", signif(min(x), 4), " to ", signif(max(x), 4), ".",
         call. = FALSE)
  rep(x, length.out = n)
}

## Codes that are not in the table for a stated reason, so the error can say
## why rather than calling them unknown.
.cw_dropped <- c("376" = paste0(
  "SPCD 376 is not shipped: it has no REF_SPECIES row, the delivered universe ",
  "drops it, and its 12 trees were fitted with genus and family recorded as ",
  "unknown."))

## Resolve species codes to rows of the parameter table. Unknown codes stop.
## allow_donor = FALSE restricts the resolution to the 220 direct fits.
## allow_none = FALSE refuses the 11 no_donor codes, whose numbers are the
## clade population equation carried for want of any defensible model;
## allow_none = TRUE, the default, returns them with a warning naming them.
.cw_resolve <- function(spcd, allow_donor = TRUE, allow_none = TRUE) {
  x <- .cw_num(spcd)
  if (any(is.na(x)))
    stop("spcd carries ", sum(is.na(x)), " missing or non integer value(s).",
         call. = FALSE)
  if (any(x != round(x)) || any(abs(x) > .Machine$integer.max))
    stop("spcd carries ", sum(x != round(x) | abs(x) > .Machine$integer.max),
         " non integer value(s), for example ",
         signif(x[x != round(x) | abs(x) > .Machine$integer.max][1L], 8),
         ". FIA species codes are whole numbers.", call. = FALSE)
  s <- as.integer(x)
  p <- .cw_load()
  i <- match(s, p[["spcd"]])
  miss <- unique(s[is.na(i)])
  drop <- intersect(miss, as.integer(names(.cw_dropped)))
  bad  <- setdiff(miss, drop)
  if (length(miss))
    stop(paste(c(
      if (length(drop)) paste(.cw_dropped[as.character(drop)], collapse = " "),
      if (length(bad)) paste0(
        "unknown FIA species code(s): ",
        paste(utils::head(sort(bad), 10L), collapse = ", "),
        if (length(bad) > 10L) paste0(" and ", length(bad) - 10L, " more") else "",
        ". cw_parameters()$spcd lists the ", nrow(p), " codes this library ",
        "covers.")), collapse = " "), call. = FALSE)
  route <- p[["extension_route"]][i]
  if (!allow_donor) {
    nd <- unique(s[route != "direct"])
    if (length(nd))
      stop("allow_donor = FALSE, and ", length(nd), " species code(s) are not ",
           "among the 220 direct fits: ",
           paste(utils::head(sort(nd), 10L), collapse = ", "),
           if (length(nd) > 10L) ", ..." else "",
           ". Set allow_donor = TRUE to resolve them through their extension ",
           "route.", call. = FALSE)
  }
  none <- unique(s[p[["confidence"]][i] == "none"])
  if (length(none)) {
    msg <- paste0(length(none), " species code(s) have no defensible crown ",
                  "model and return the clade population equation, ",
                  "confidence 'none': ",
                  paste(utils::head(sort(none), 10L), collapse = ", "),
                  if (length(none) > 10L) ", ..." else "",
                  ". See cw_parameters()$note.")
    if (!allow_none)
      stop("allow_none = FALSE, and ", msg, call. = FALSE)
    warning(msg, call. = FALSE)
  }
  i
}

## ---- the recipe ------------------------------------------------------------

## Steps 1 to 3, applied elementwise. Returns the MCW envelope in feet.
## hold_domain = FALSE skips step 2, apply_ceiling = FALSE skips step 3; both
## are provided so the raw curve can be reproduced deliberately, which is the
## only way it should ever be reproduced.
.cw_mcw_core <- function(dbh, a1, a2, dbh_max_fit, cw_ceiling,
                         hold_domain = TRUE, apply_ceiling = TRUE) {
  d <- dbh
  if (isTRUE(hold_domain)) {
    over <- is.finite(d) & is.finite(dbh_max_fit) & d > dbh_max_fit
    d[over] <- dbh_max_fit[over]
  }
  out <- a1 * d ^ a2
  if (isTRUE(apply_ceiling)) {
    bind <- is.finite(out) & is.finite(cw_ceiling) & out > cw_ceiling
    out[bind] <- cw_ceiling[bind]
  }
  out
}

## The bounded Beta ratio, evaluated on the same diameter the MCW curve saw so
## that LCW is flat above dbh_max_fit exactly where MCW is.
.cw_ratio <- function(dbh, cr, ratio_intercept, ratio_cr, ratio_dbh) {
  eta <- ratio_intercept + ratio_cr * cr + ratio_dbh * dbh
  1 / (1 + exp(-eta))
}

## Per element provenance, attached to every return value. It carries the
## coefficient intervals, so a borrowed prediction never travels without the
## uncertainty the universe assigned it.
.cw_prov_cols <- c("common_name", "clade", "extension_route", "confidence",
                   "fit_evidence", "source_spcd", "donor_is_prior_dominated",
                   "c_cal", "env_source", "env_source_spcd",
                   "a1", "a1_ci95_lo", "a1_ci95_hi",
                   "a2", "a2_ci95_lo", "a2_ci95_hi",
                   "n_obs", "donor_n_obs", "extrap_flag_range",
                   "dbh_min_fit", "dbh_max_fit",
                   "cw_ceiling", "cw_shipped_max", "param_source_md5")

.cw_provenance <- function(p, i, spcd) {
  out <- data.table::data.table(spcd = spcd)
  for (j in .cw_prov_cols) data.table::set(out, j = j, value = p[[j]][i])
  out
}
