## ---------------------------------------------------------------------------
## mcw.R -- maximum (open grown) crown width.
## ---------------------------------------------------------------------------

#' Maximum crown width
#'
#' Maximum crown width, the open grown crown width envelope, for CONUS tree
#' species. The underlying equation is the power form
#' \code{cw_ft = exp(la1) * dbh_in^a2}, fitted as a Bayesian hierarchical
#' quantile regression at \code{tau = 0.95} with species nested in family and
#' crossed with EPA Level III ecoregion, the ecoregion effect marginalized out.
#' The level carries a crown ratio term and the shipped coefficients are that
#' level evaluated at \code{cr = 1}, which is the open grown statement. Users
#' supply no coefficients: the whole library travels with the package.
#'
#' The returned value is the shipped recipe, three steps in a load bearing
#' order. First the curve is evaluated on the trait corrected level, which is
#' what the \code{a1} column of the parameter table carries. Second, for any
#' diameter above \code{dbh_max_fit} the diameter is held at
#' \code{dbh_max_fit}, so the curve is never evaluated above the range it was
#' fitted over. Below \code{dbh_min_fit} nothing is held; the provenance
#' column \code{below_fit_domain} flags those elements. Third, the result is capped at \code{cw_ceiling}, the widest
#' crown observed in that clade, 75.0 ft hardwood and 65.2 ft softwood.
#'
#' The third step is not implied by the second. For the 13 species carrying
#' \code{ceiling_binds_in_fit}, the curve breaches the ceiling inside its own
#' fitted range, so \code{a1 * dbh_max_fit^a2} is itself above the ceiling and
#' only the cap brings it down. Eastern cottonwood, SPCD 742, is the clear
#' case: \code{cw_at_dbh_max} is 101.13 ft against a 75.0 ft ceiling, and the
#' value the recipe actually returns at and above \code{dbh_max_fit} is the
#' library column \code{cw_shipped_max}, which is
#' \code{min(cw_at_dbh_max, cw_ceiling)}. Code that reads \code{cw_at_dbh_max}
#' on its own is wrong for those species.
#'
#' Of the 523 FIA codes the package covers, 220 carry their own fit. The rest
#' are resolved through the extension cascade of the delivered universe: a
#' donor in the same genus (146), a hand override (8, the seven
#' \emph{Cupressus} to incense-cedar and giant sequoia to redwood), a donor in
#' the same FIA species group (67), or the clade population equation (71,
#' including 39 tropical and large statured codes routed there by hand).
#' Eleven more codes, palms, \emph{Yucca brevifolia} Engelm. and placeholder
#' names that are not taxa, have no defensible donor; they return the clade
#' population equation with confidence \code{"none"} and a warning. Every
#' return value carries per element provenance: the route, the donor, the two
#' confidence axes, and the 95 percent intervals on \code{a1} and \code{a2},
#' which for a borrowed code are the donor's widened for the between species
#' spread and scaled by the per route \code{c_cal}.
#'
#' @param spcd FIA species code, integer. Length 1 (recycled) or
#'   \code{length(dbh_in)}.
#' @param dbh_in Diameter at breast height, INCHES. Length 1 (recycled) or
#'   \code{length(spcd)}.
#' @param hold_domain Logical, default \code{TRUE}. Step 2 of the recipe, the
#'   domain hold at \code{dbh_max_fit}. Set \code{FALSE} only to reproduce the
#'   raw curve deliberately; the power form has no asymptote and past its
#'   fitted range it returns crown widths no North American tree carries.
#' @param apply_ceiling Logical, default \code{TRUE}. Step 3 of the recipe, the
#'   per clade observed crown ceiling.
#' @param allow_donor Logical, default \code{TRUE}. Resolve a code without its
#'   own fit through its extension route. \code{FALSE} restricts the call to
#'   the 220 direct fits and errors on anything else.
#' @param allow_none Logical, default \code{TRUE}. For the 11 codes with
#'   confidence \code{"none"}, return the clade population value with a
#'   warning. \code{FALSE} makes them an error.
#' @param details Logical, default \code{FALSE}. \code{TRUE} returns a
#'   \code{data.table} of the prediction alongside its provenance instead of a
#'   bare numeric vector.
#'
#' @return A numeric vector of maximum crown width in FEET, the same length as
#'   the recycled arguments, carrying an attribute \code{"provenance"}: a
#'   \code{data.table} with one row per element giving
#'   \code{extension_route}, \code{confidence}, \code{fit_evidence},
#'   \code{source_spcd}, \code{donor_is_prior_dominated}, \code{c_cal},
#'   \code{env_source}, \code{env_source_spcd}, \code{a1} and \code{a2} with
#'   their 95 percent intervals, \code{n_obs}, \code{donor_n_obs}, the fitted
#'   domain, the ceiling and \code{param_source_md5}. The coefficient
#'   intervals are marginal; the universe does not carry their covariance, so
#'   no joint prediction interval is computed from them. With \code{details = TRUE} that table is returned directly with
#'   \code{dbh_in} and \code{mcw_ft} bound on.
#'
#' @section Units:
#' DBH in inches, crown width in feet, throughout. The library was fit on this
#' scale; the metric library is an analytic conversion of the same fits and is
#' not what this package carries.
#'
#' @section Errors:
#' An unknown species code, a negative DBH and a missing DBH all stop rather
#' than return \code{NA}, because each is a data problem the caller should see.
#'
#' @examples
#' ## Douglas-fir, SPCD 202, fitted over 5.0 to 68.66 in DBH.
#' mcw(202, c(10, 30, 60, 90))
#' ## 21.6483 39.4915 57.7067 62.1257  feet
#' ## The last one is above dbh_max_fit, so it is held: it equals
#' ## cw_parameters()[spcd == 202, cw_shipped_max], 62.1257 ft.
#'
#' ## What the hold is worth. The raw curve keeps climbing:
#' mcw(202, 90, hold_domain = FALSE, apply_ceiling = FALSE)
#' ## 72.0416 feet
#'
#' ## Eastern cottonwood, SPCD 742, where the ceiling and not the hold binds.
#' ## It is fit to 57.9 in, but its curve reaches the 75.0 ft hardwood ceiling
#' ## at 39.04 in, two thirds of the way up its own fitted range.
#' mcw(742, c(20, 39.0416837, 50, 80))
#' ## 45.1572 75.0000 75.0000 75.0000  feet
#' mcw(742, c(20, 39.0416837, 50, 80), hold_domain = FALSE, apply_ceiling = FALSE)
#' ## 45.1572 75.0000 90.4800 129.2324  feet, the raw curve
#'
#' ## A species with no fit of its own. Fraser fir, SPCD 16, is carried by
#' ## balsam fir, SPCD 12, so the two return the same numbers and the
#' ## provenance says so.
#' mcw(16, c(8, 15, 25))
#' ## 18.0429 24.6967 27.4974  feet
#' pv <- attr(mcw(16, 15), "provenance")
#' pv$source_spcd       # 12
#' pv$confidence        # "genus_proxy"
#' pv$fit_evidence      # "self_informed", balsam fir's own fit
#' ## the donor's a1 interval, widened for borrowing
#' pv[, .(a1, a1_ci95_lo, a1_ci95_hi, c_cal)]
#'
#' ## Vectorized over both arguments.
#' mcw(c(202, 742, 16), c(20, 20, 20))
#'
#' @seealso \code{\link{lcw}}, \code{\link{cw_parameters}}
#' @export
mcw <- function(spcd, dbh_in, hold_domain = TRUE, apply_ceiling = TRUE,
                allow_donor = TRUE, allow_none = TRUE, details = FALSE) {
  hold_domain   <- .cw_flag(hold_domain, "hold_domain")
  apply_ceiling <- .cw_flag(apply_ceiling, "apply_ceiling")
  allow_donor   <- .cw_flag(allow_donor, "allow_donor")
  allow_none    <- .cw_flag(allow_none, "allow_none")
  d <- .cw_check_dbh(dbh_in)
  rc <- .cw_recycle(spcd, d)
  i <- .cw_resolve(rc$spcd, allow_donor = allow_donor,
                   allow_none = allow_none)
  p <- .cw_load()
  out <- .cw_mcw_core(rc$dbh, p[["a1"]][i], p[["a2"]][i],
                      p[["dbh_max_fit"]][i], p[["cw_ceiling"]][i],
                      hold_domain = hold_domain, apply_ceiling = apply_ceiling)
  prov <- .cw_provenance(p, i, as.integer(.cw_num(rc$spcd)))
  data.table::set(prov, j = "dbh_in", value = rc$dbh)
  data.table::set(prov, j = "below_fit_domain",
                  value = rc$dbh < p[["dbh_min_fit"]][i])
  data.table::set(prov, j = "mcw_ft", value = as.numeric(out))
  if (isTRUE(details)) return(prov[])
  out <- as.numeric(out)
  attr(out, "provenance") <- prov[]
  out
}
