## ---------------------------------------------------------------------------
## lcw.R -- largest crown width, a bounded fraction of MCW.
## ---------------------------------------------------------------------------

#' Largest crown width
#'
#' Largest crown width, the stand grown crown width, for CONUS tree species.
#' LCW is not fit as its own allometry. It is a bounded fraction of the maximum
#' crown width envelope,
#' \code{LCW = MCW * ratio} with
#' \code{logit(ratio) = ratio_intercept + ratio_cr * cr + ratio_dbh * dbh},
#' the ratio a Beta regression at \code{tau = 0.50} fit against the clade split
#' MCW envelope. Since the ratio lies strictly in (0, 1), LCW is below MCW for
#' every species at every diameter by construction rather than by a check.
#'
#' The MCW envelope underneath is the shipped recipe in the same load bearing
#' order documented at \code{\link{mcw}}: the trait corrected level, then the
#' domain hold at \code{dbh_max_fit}, then the \code{cw_ceiling} cap. The ratio
#' is evaluated on the held diameter rather than the requested one, so LCW goes
#' flat above \code{dbh_max_fit} exactly where MCW does instead of drifting on
#' through the \code{ratio_dbh} term.
#'
#' @param spcd FIA species code, integer. Length 1 (recycled) or
#'   \code{length(dbh_in)}.
#' @param dbh_in Diameter at breast height, INCHES. Length 1 (recycled) or
#'   \code{length(spcd)}.
#' @param cr Crown ratio as a PROPORTION in (0, 1], default 1. Length 1 or the
#'   recycled length; \code{cr} participates in the recycling, so
#'   \code{lcw(202, 30, cr = c(0.2, 0.6, 1))} returns three values. The default is
#'   the open grown statement, matching the crown ratio the MCW level is
#'   delivered at, and it makes \code{lcw()} the widest crown the ratio model
#'   allows. Pass the stand's own crown ratios for a stand grown prediction.
#'   The fitting sample spans cr 0.05 to 0.99, so cr = 1 is a one hundredth
#'   step past the observed maximum and is a convention, not a measurement.
#' @param hold_domain Logical, default \code{TRUE}. The domain hold at
#'   \code{dbh_max_fit}, applied to the MCW envelope and to the ratio alike.
#' @param apply_ceiling Logical, default \code{TRUE}. The per clade observed
#'   crown ceiling on the MCW envelope.
#' @param allow_donor Logical, default \code{TRUE}. Resolve a code without its
#'   own fit through its extension route; \code{FALSE} restricts the call to
#'   the 220 direct fits.
#' @param allow_none Logical, default \code{TRUE}. Return the clade population
#'   value, with a warning, for the 11 codes with confidence \code{"none"};
#'   \code{FALSE} makes them an error.
#' @param details Logical, default \code{FALSE}. \code{TRUE} returns a
#'   \code{data.table} of the prediction, the ratio and the provenance instead
#'   of a bare numeric vector.
#'
#' @return A numeric vector of largest crown width in FEET, the same length as
#'   the recycled arguments, carrying a \code{"provenance"} attribute of the
#'   same shape as \code{\link{mcw}} returns, with \code{cr}, \code{cw_ratio}
#'   and \code{lcw_ft} bound on.
#'
#' @examples
#' ## Douglas-fir, SPCD 202, at the open grown default cr = 1.
#' lcw(202, c(10, 30, 60, 90))
#' ## 18.4095 33.9699 50.4278 54.5211  feet
#' ## Against the matching envelope:
#' mcw(202, c(10, 30, 60, 90))
#' ## 21.6483 39.4915 57.7067 62.1257  feet
#'
#' ## Eastern cottonwood, SPCD 742, where the MCW ceiling binds from 39.04 in
#' ## up and drags LCW flat with it.
#' lcw(742, c(20, 39.0416837, 50, 80))
#' ## 39.4828 66.1794 66.5114 66.7440  feet
#'
#' ## A stand grown crown ratio rather than the open grown default.
#' lcw(202, 30, cr = 0.4)
#' ## 25.9840 feet
#'
#' ## The ratio itself, when it is the quantity of interest.
#' lcw(202, 30, details = TRUE)$cw_ratio
#'
#' @seealso \code{\link{mcw}}, \code{\link{cw_parameters}}
#' @export
lcw <- function(spcd, dbh_in, cr = 1, hold_domain = TRUE, apply_ceiling = TRUE,
                allow_donor = TRUE, allow_none = TRUE, details = FALSE) {
  hold_domain   <- .cw_flag(hold_domain, "hold_domain")
  apply_ceiling <- .cw_flag(apply_ceiling, "apply_ceiling")
  allow_donor   <- .cw_flag(allow_donor, "allow_donor")
  allow_none    <- .cw_flag(allow_none, "allow_none")
  d <- .cw_check_dbh(dbh_in)
  rc <- .cw_recycle(spcd, d, length(cr))
  crv <- .cw_check_cr(cr, rc$n)
  i <- .cw_resolve(rc$spcd, allow_donor = allow_donor,
                   allow_none = allow_none)
  p <- .cw_load()

  env <- .cw_mcw_core(rc$dbh, p[["a1"]][i], p[["a2"]][i],
                      p[["dbh_max_fit"]][i], p[["cw_ceiling"]][i],
                      hold_domain = hold_domain, apply_ceiling = apply_ceiling)

  ## the ratio sees the held diameter, so LCW is flat above dbh_max_fit exactly
  ## where MCW is; between dbh_at_ceiling and dbh_max_fit MCW is capped while
  ## the ratio still rises with dbh, so LCW keeps a slight upward slope there
  dr <- rc$dbh
  if (isTRUE(hold_domain)) {
    over <- is.finite(dr) & is.finite(p[["dbh_max_fit"]][i]) &
            dr > p[["dbh_max_fit"]][i]
    dr[over] <- p[["dbh_max_fit"]][i][over]
  }
  ratio <- .cw_ratio(dr, crv, p[["ratio_intercept"]][i], p[["ratio_cr"]][i],
                     p[["ratio_dbh"]][i])
  out <- env * ratio

  prov <- .cw_provenance(p, i, as.integer(.cw_num(rc$spcd)))
  data.table::set(prov, j = "dbh_in",   value = rc$dbh)
  data.table::set(prov, j = "below_fit_domain",
                  value = rc$dbh < p[["dbh_min_fit"]][i])
  data.table::set(prov, j = "cr",       value = crv)
  data.table::set(prov, j = "mcw_ft",   value = as.numeric(env))
  data.table::set(prov, j = "cw_ratio", value = as.numeric(ratio))
  data.table::set(prov, j = "lcw_ft",   value = as.numeric(out))
  if (isTRUE(details)) return(prov[])
  out <- as.numeric(out)
  attr(out, "provenance") <- prov[]
  out
}
